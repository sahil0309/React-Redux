
import * as React from 'react';

const NotFound = () =>{
    return(
    <div>
        <h3>PageNotFound</h3>
        </div>
    )
  }

 export default NotFound;