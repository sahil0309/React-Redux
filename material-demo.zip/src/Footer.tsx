import * as React from 'react';
import './Footer.css';

class Footer extends React.Component{
    render(){
        return(
        <div className="footer">
        <p>Footer</p>
            </div>)
    }
}

export default Footer;